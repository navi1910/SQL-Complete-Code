# SELECT - FROM - solution
SELECT

    dept_no

FROM

    departments;

 

SELECT

    *

FROM

    departments;