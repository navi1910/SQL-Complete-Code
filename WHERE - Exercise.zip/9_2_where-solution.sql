# WHERE - solution

SELECT

    *

FROM

    employees

WHERE

    first_name = 'Elvis';