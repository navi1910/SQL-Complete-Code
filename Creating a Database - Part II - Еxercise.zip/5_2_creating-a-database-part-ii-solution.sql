# SOLUTION - Creating a Database - Part II


USE Sales;
