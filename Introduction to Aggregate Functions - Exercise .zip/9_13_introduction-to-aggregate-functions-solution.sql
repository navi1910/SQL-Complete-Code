# Introduction to aggregate functions - solution

SELECT

    COUNT(*)

FROM

    salaries

WHERE

    salary >= 100000;

SELECT

    COUNT(*)

FROM

    dept_manager;