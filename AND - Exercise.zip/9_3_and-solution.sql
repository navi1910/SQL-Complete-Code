# AND - solution

SELECT

    *

FROM

    employees

WHERE

    first_name = 'Kellie' AND gender = 'F'; 