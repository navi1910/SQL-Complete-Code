# ORDER BY - solution

SELECT

    *

FROM

    employees

ORDER BY hire_date DESC;