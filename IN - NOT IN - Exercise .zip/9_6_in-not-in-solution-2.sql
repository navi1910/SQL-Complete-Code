# IN - NOT IN - solution 2
SELECT

    *

FROM

    employees

WHERE

    first_name NOT IN ('John' , 'Mark', 'Jacob');