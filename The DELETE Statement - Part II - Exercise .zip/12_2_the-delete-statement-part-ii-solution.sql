# The DELETE Statement – Part II - solution

DELETE FROM departments

WHERE

    dept_no = 'd010';