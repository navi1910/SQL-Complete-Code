# SELECT DISTINCT - solution

SELECT DISTINCT

    hire_date

FROM

    employees;