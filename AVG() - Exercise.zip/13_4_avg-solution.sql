# AVG() - solution

SELECT

    AVG(salary)

FROM

    salaries

WHERE

    from_date > '1997-01-01';