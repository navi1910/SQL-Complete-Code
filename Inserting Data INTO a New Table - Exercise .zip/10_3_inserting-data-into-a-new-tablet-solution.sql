# Inserting Data INTO a New Table - solution

INSERT INTO departments VALUES ('d010', 'Business Analysis');