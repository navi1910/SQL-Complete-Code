# NOT NULL Constraint - Part I - solution
ALTER TABLE companies

MODIFY headquarters_phone_number VARCHAR(255) NULL;

 

ALTER TABLE companies

CHANGE COLUMN headquarters_phone_number headquarters_phone_number VARCHAR(255) NOT NULL;