# FOREIGN KEY constraint - Part II - solution
DROP TABLE sales;

DROP TABLE customers;

DROP TABLE items;

DROP TABLE companies;