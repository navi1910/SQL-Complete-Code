# IS NOT NULL - IS NULL - solution

SELECT

    dept_name

FROM

    departments

WHERE

    dept_no IS NOT NULL;