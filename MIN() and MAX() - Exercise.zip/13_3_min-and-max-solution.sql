# MIN() and MAX() - solution

#1

SELECT

    MIN(emp_no)

FROM

    employees;

#2

SELECT

    MAX(emp_no)

FROM

    employees;

