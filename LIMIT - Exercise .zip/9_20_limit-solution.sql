# LIMIT - solution

SELECT
    *
FROM
    dept_emp
LIMIT 100;