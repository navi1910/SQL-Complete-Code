# COUNT() - solution

SELECT

    COUNT(DISTINCT dept_no)

FROM

    dept_emp;