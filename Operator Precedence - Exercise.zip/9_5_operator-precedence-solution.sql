# Operator precedence - solution
SELECT

    *

FROM

    employees

WHERE

    gender = 'F' AND (first_name = 'Kellie' OR first_name = 'Aruna');